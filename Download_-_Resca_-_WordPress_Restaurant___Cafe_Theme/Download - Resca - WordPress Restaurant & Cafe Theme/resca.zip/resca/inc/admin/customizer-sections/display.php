<?php
$url = TP_THEME_URI . 'images/admin/layout/';

$display = $titan->createThimCustomizerSection( array(
	'name'     => 'Display',
	'position' => 5,
	'id'       => 'display',
) );