<?php
/*
 * Creating a Styling Options
 */

$styling = $titan->createThimCustomizerSection( array(
	'name'     => 'Styling',
	'position' => 4,
	'id'=>'styling'
) );

