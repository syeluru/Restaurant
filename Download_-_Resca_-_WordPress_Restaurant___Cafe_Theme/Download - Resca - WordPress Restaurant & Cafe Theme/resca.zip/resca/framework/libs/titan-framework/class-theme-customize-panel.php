<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of class-theme-customize-panel
 *
 * @author Tuannv
 */
class TitanFrameworkThemeCustomizerPanel {

    private $defaultSettings = array(
        'priority' => 10,
        'capability' => 'edit_theme_options',
        'theme_supports' => '',
        'title' => '',
        'description' => '',
    );

}
